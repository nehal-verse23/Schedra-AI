# Schedra AI — Student Study Workspace

A responsive frontend MVP for the Schedra AI Software Engineering project.

## Features
- Dashboard with task, session, notes and progress summaries
- Study schedule: add, edit and delete sessions
- To-do list: priorities, due dates, completion and filters
- Notes: create, edit, delete and search notes
- Progress page: task completion percentage and session count
- Study planner: creates a suggested subject rotation from user inputs
- Local browser storage using `localStorage`

## Run the project
1. Download and extract `Schedra_AI_Project.zip`.
2. Open the `Schedra_AI` folder.
3. Double-click `index.html` to open it in Chrome, Edge or Firefox.

No installation or server is required for this frontend prototype.

## Important implementation note
The current study planner is a rule-based prototype, not a live generative AI integration. Data is stored in the browser where the app is opened. A later version can add a Python/Flask backend, user accounts, a shared database, and a real AI API.

## Project structure
- `index.html` — page structure
- `style.css` — responsive UI styling
- `app.js` — app functionality and localStorage data handling
