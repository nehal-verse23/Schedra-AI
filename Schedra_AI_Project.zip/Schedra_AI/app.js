const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const storeKey = "schedra-ai-v1";
const defaultData = {tasks:[], sessions:[], notes:[]};
let data = loadData();
let modalType = null;
let editingId = null;

function loadData(){try{return {...defaultData,...JSON.parse(localStorage.getItem(storeKey)||"{}")}}catch{return {...defaultData}}}
function save(){localStorage.setItem(storeKey,JSON.stringify(data));renderAll()}
function id(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function escapeHtml(v=""){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function dateLabel(d){if(!d)return "No date";return new Date(d+"T00:00:00").toLocaleDateString(undefined,{day:"numeric",month:"short",year:"numeric"})}
function todayISO(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2300)}
function go(page){$$(".page").forEach(p=>p.classList.toggle("active-page",p.id===`page-${page}`));$$(".nav-item").forEach(n=>n.classList.toggle("active",n.dataset.page===page));$("#crumb").textContent=({dashboard:"Dashboard",schedule:"Study schedule",tasks:"My tasks",notes:"Notes",progress:"Progress",planner:"AI planner"})[page];$("#sidebar").classList.remove("open");renderAll()}
$$(".nav-item").forEach(b=>b.addEventListener("click",()=>go(b.dataset.page)));
$$("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
$("#mobileMenu").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
$("#todayLabel").textContent=new Date().toLocaleDateString(undefined,{weekday:"short",day:"numeric",month:"short"});
const hr=new Date().getHours();$("#greeting").innerHTML=(hr<12?"Good morning":hr<17?"Good afternoon":"Good evening")+", Student <span>✦</span>";

function renderAll(){renderDashboard();renderTasks();renderSessions();renderNotes();renderProgress()}
function renderDashboard(){
 const done=data.tasks.filter(t=>t.done).length,total=data.tasks.length,rate=total?Math.round(done/total*100):0;
 $("#completedCount").textContent=done;$("#taskTotal").textContent=`${total} total task${total===1?"":"s"}`;$("#taskBar").style.width=rate+"%";
 $("#sessionCount").textContent=data.sessions.length;$("#noteCount").textContent=data.notes.length;$("#overallProgress").innerHTML=rate+'<span class="percent">%</span>';
 $("#focusPercent").textContent=rate+"%";$("#focusRing").style.background=`conic-gradient(#7968d8 ${rate*3.6}deg,#eeeafd 0deg)`;
 $("#focusTasks").textContent=total?`${done} of ${total} tasks completed`:"No tasks completed yet";$("#focusSub").textContent=total?`${total-done} task${total-done===1?"":"s"} left to go`:"Add a task to get started.";
 const today=data.sessions.filter(s=>s.date===todayISO()).sort((a,b)=>a.time.localeCompare(b.time));
 $("#todaySchedule").innerHTML=today.length?today.map(s=>`<div class="schedule-row"><div class="schedule-time">${escapeHtml(s.time)}</div><div class="schedule-color"></div><div class="schedule-info"><strong>${escapeHtml(s.subject)}</strong><span>${escapeHtml(s.duration)} min study session</span></div><span class="subject-tag">${escapeHtml(s.topic||"Study")}</span></div>`).join(""):`<div class="empty-list"><b>No sessions planned for today</b>Add a study session to organize your day.</div>`;
 const priorities=data.tasks.filter(t=>!t.done).sort((a,b)=>({High:0,Medium:1,Low:2}[a.priority]-{High:0,Medium:1,Low:2}[b.priority])).slice(0,4);
 $("#priorityList").innerHTML=priorities.length?priorities.map(t=>`<div class="priority-row"><button class="priority-check" onclick="toggleTask('${t.id}')"></button><div class="priority-info"><strong>${escapeHtml(t.title)}</strong><span>${t.due?`Due ${dateLabel(t.due)}`:"No deadline"}</span></div><span class="priority-priority">${escapeHtml(t.priority)}</span></div>`).join(""):`<div class="empty-list"><b>You're all caught up!</b>Add tasks to see your priorities here.</div>`;
}
function renderTasks(){
 const filter=$("#taskFilter").value;let list=[...data.tasks].sort((a,b)=>(a.done-b.done)||((a.due||"").localeCompare(b.due||"")));
 if(filter==="pending")list=list.filter(t=>!t.done);if(filter==="completed")list=list.filter(t=>t.done);
 $("#allTasks").innerHTML=list.length?list.map(t=>`<div class="task-row ${t.done?"is-done":""}"><button class="task-check ${t.done?"checked":""}" onclick="toggleTask('${t.id}')">${t.done?"✓":""}</button><div class="task-text"><strong>${escapeHtml(t.title)}</strong><small>${escapeHtml(t.subject||"General")} · ${t.due?`Due ${dateLabel(t.due)}`:"No deadline"}</small></div><span class="priority-pill ${escapeHtml(t.priority)}">${escapeHtml(t.priority)}</span><button class="small-action" onclick="editItem('task','${t.id}')">Edit</button><button class="small-action delete-action" onclick="removeItem('task','${t.id}')">Delete</button></div>`).join(""):`<div class="empty-list"><b>No tasks found</b>Add a task and make your next step count.</div>`;
}
function renderSessions(){
 const list=[...data.sessions].sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));
 $("#sessionTotal").textContent=`${list.length} session${list.length===1?"":"s"}`;
 $("#allSessions").innerHTML=list.length?list.map(s=>`<div class="table-row"><div class="row-main"><span class="row-dot"></span><div><strong>${escapeHtml(s.subject)}</strong><small>${dateLabel(s.date)} · ${escapeHtml(s.time)} · ${escapeHtml(s.duration)} minutes ${s.topic?"· "+escapeHtml(s.topic):""}</small></div></div><div class="row-actions"><button class="small-action" onclick="editItem('session','${s.id}')">Edit</button><button class="small-action delete-action" onclick="removeItem('session','${s.id}')">Delete</button></div></div>`).join(""):`<div class="empty-list"><b>No study sessions yet</b>Create your first session to build a study routine.</div>`;
}
function renderNotes(){
 const q=$("#noteSearch").value.toLowerCase();const list=[...data.notes].filter(n=>(n.title+" "+n.subject+" "+n.body).toLowerCase().includes(q)).sort((a,b)=>b.updated-a.updated);
 $("#notesTotal").textContent=`${list.length} note${list.length===1?"":"s"}`;
 $("#notesGrid").innerHTML=list.length?list.map(n=>`<article class="note-card"><span class="note-subject">${escapeHtml(n.subject||"General")}</span><h3>${escapeHtml(n.title)}</h3><p>${escapeHtml(n.body)}</p><div class="note-footer"><span>Updated ${new Date(n.updated).toLocaleDateString()}</span><span><button class="small-action" onclick="editItem('note','${n.id}')">Edit</button> <button class="small-action delete-action" onclick="removeItem('note','${n.id}')">Delete</button></span></div></article>`).join(""):`<div class="empty-list"><b>No notes found</b>Create a note to keep your learning organized.</div>`;
}
function renderProgress(){
 const done=data.tasks.filter(t=>t.done).length,total=data.tasks.length,rate=total?Math.round(done/total*100):0;
 $("#progressCompleted").textContent=done;$("#progressRate").textContent=rate+"%";$("#progressSessions").textContent=data.sessions.length;
 $("#progressFill").style.width=rate+"%";$("#progressDoneLabel").textContent=done;$("#progressRemaining").textContent=total-done;
}
$("#taskFilter").addEventListener("change",renderTasks);$("#noteSearch").addEventListener("input",renderNotes);

function openModal(type,item=null){
 modalType=type;editingId=item?.id||null;const editing=!!item;
 const fields=$("#modalFields");$("#modalTitle").textContent=(editing?"Edit ":"Add ")+({task:"task",session:"study session",note:"note"}[type]);
 if(type==="task")fields.innerHTML=`<label>Task name</label><input name="title" required maxlength="90" placeholder="e.g. Complete assignment 2" value="${escapeHtml(item?.title||"")}"><label>Subject</label><input name="subject" placeholder="e.g. Mathematics" value="${escapeHtml(item?.subject||"")}"><div class="form-two"><div><label>Due date</label><input name="due" type="date" value="${item?.due||""}"></div><div><label>Priority</label><select name="priority"><option ${item?.priority==="Low"?"selected":""}>Low</option><option ${!item||item.priority==="Medium"?"selected":""}>Medium</option><option ${item?.priority==="High"?"selected":""}>High</option></select></div></div>`;
 if(type==="session")fields.innerHTML=`<label>Subject</label><input name="subject" required placeholder="e.g. Data Structures" value="${escapeHtml(item?.subject||"")}"><label>Topic (optional)</label><input name="topic" placeholder="e.g. Linked lists" value="${escapeHtml(item?.topic||"")}"><div class="form-two"><div><label>Date</label><input name="date" type="date" required value="${item?.date||todayISO()}"></div><div><label>Start time</label><input name="time" type="time" required value="${item?.time||"17:00"}"></div></div><label>Duration (minutes)</label><select name="duration">${[25,30,45,60,90,120].map(v=>`<option value="${v}" ${String(item?.duration||60)===String(v)?"selected":""}>${v} minutes</option>`).join("")}</select>`;
 if(type==="note")fields.innerHTML=`<label>Note title</label><input name="title" required maxlength="90" placeholder="e.g. Binary search notes" value="${escapeHtml(item?.title||"")}"><label>Subject</label><input name="subject" placeholder="e.g. DSA" value="${escapeHtml(item?.subject||"")}"><label>Your notes</label><textarea name="body" required placeholder="Write your key points here...">${escapeHtml(item?.body||"")}</textarea>`;
 $("#modalBackdrop").classList.add("show");setTimeout(()=>fields.querySelector("input")?.focus(),50);
}
function closeModal(){$("#modalBackdrop").classList.remove("show");$("#itemForm").reset();modalType=null;editingId=null}
$("#closeModal").onclick=closeModal;$("#cancelModal").onclick=closeModal;$("#modalBackdrop").addEventListener("click",e=>{if(e.target.id==="modalBackdrop")closeModal()});
$("#addTaskBtn").onclick=()=>openModal("task");$("#quickAdd").onclick=()=>openModal("task");$("#addSessionBtn").onclick=()=>openModal("session");$("#addNoteBtn").onclick=()=>openModal("note");
$("#itemForm").addEventListener("submit",e=>{
 e.preventDefault();const obj=Object.fromEntries(new FormData(e.target).entries());
 if(modalType==="task"){const old=data.tasks.find(x=>x.id===editingId);const item={...obj,id:editingId||id(),done:old?.done||false};if(editingId)data.tasks=data.tasks.map(x=>x.id===editingId?item:x);else data.tasks.push(item)}
 if(modalType==="session"){const item={...obj,id:editingId||id()};if(editingId)data.sessions=data.sessions.map(x=>x.id===editingId?item:x);else data.sessions.push(item)}
 if(modalType==="note"){const item={...obj,id:editingId||id(),updated:Date.now()};if(editingId)data.notes=data.notes.map(x=>x.id===editingId?item:x);else data.notes.push(item)}
 closeModal();save();toast("Saved successfully!");
});
function toggleTask(taskId){data.tasks=data.tasks.map(t=>t.id===taskId?{...t,done:!t.done}:t);save();toast("Task updated")}
function editItem(type,itemId){const arr=type==="task"?data.tasks:type==="session"?data.sessions:data.notes;const item=arr.find(x=>x.id===itemId);if(item)openModal(type,item)}
function removeItem(type,itemId){if(!confirm("Delete this item?"))return;const key=type==="task"?"tasks":type==="session"?"sessions":"notes";data[key]=data[key].filter(x=>x.id!==itemId);save();toast("Deleted")}
window.toggleTask=toggleTask;window.editItem=editItem;window.removeItem=removeItem;

$("#plannerForm").addEventListener("submit",e=>{
 e.preventDefault();const subjects=$("#plannerSubjects").value.split(",").map(s=>s.trim()).filter(Boolean);
 if(!subjects.length){toast("Please enter at least one subject.");return}
 const hours=Number($("#plannerHours").value),days=Number($("#plannerDays").value),goal=$("#plannerGoal").value;
 const totalSlots=hours*2;const start=17*60;let html="";
 for(let day=0;day<days;day++){
   html+=`<div class="plan-day"><div class="eyebrow" style="margin:13px 0 7px">DAY ${day+1}</div>`;
   for(let slot=0;slot<totalSlots;slot++){
     const subject=subjects[(day*totalSlots+slot)%subjects.length];
     const mins=start+slot*30;const time=`${String(Math.floor(mins/60)%24).padStart(2,"0")}:${String(mins%60).padStart(2,"0")}`;
     const activity=slot%2===1?"Practice / active recall":goal.includes("Revise")?"Revision":"Learn a topic";
     html+=`<div class="plan-item"><div class="plan-time">${time}</div><div><strong>${escapeHtml(subject)} — ${activity}</strong><span>30 minutes · Take a 5-minute break after this session</span></div></div>`;
   }
   html+="</div>";
 }
 $("#generatedPlan").classList.remove("empty-state");$("#generatedPlan").innerHTML=html;$("#planSubtitle").textContent=`${subjects.length} subjects · ${hours} hour${hours>1?"s":""} per day · ${days} days`;
 toast("Your study plan is ready!");
});

renderAll();
